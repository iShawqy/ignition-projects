SELECT *
FROM 
    users
WHERE active = 1
ORDER BY id desc
