UPDATE messages
SET status = :status
WHERE id = :id;