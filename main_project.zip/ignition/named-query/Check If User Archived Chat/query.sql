SELECT archived from chats
WHERE id = :chatId AND archived_by = :archived_by AND archived = 1