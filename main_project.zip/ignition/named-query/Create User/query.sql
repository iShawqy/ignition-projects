INSERT INTO users (username, email, password, first_name, last_name, active)
VALUES (:username, :email, :password,:first_name, :last_name, :active);
