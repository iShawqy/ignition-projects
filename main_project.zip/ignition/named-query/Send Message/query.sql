INSERT INTO messages (`from`, `text`)
VALUES (:from, :text);
